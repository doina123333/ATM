﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
   public class Person
    {
        //e, last_name, email, card_number (9 digits), pin_code (4 digits)        stored, and initial balance
        public string first_name { get; set; }
        public string last_name { get; set; }
       
      
        public Person()
        {
            first_name = "User";
            last_name = "1";



        }
    }
}
